<?php
include_once 'conexion.php';
$objeto = new conexion();
$conexion = $objeto->conectar();

$consulta = "SELECT id_categoria, nombre_categoria FROM categoria";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width-divece-width, initial-scale=1 shrink-to-fit=no">
	<link rel="shortcut icon" href="#">
<title>Documento sin título</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="main.css">
	
	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css">
	<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<body>
<header>
	
	</header>
	
	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal">Nuevo</button>
		</div>
		</div>
	</div>
	
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="table-responsive">
				<table id="tablaCategoria" class="table table-striped table-bordered table-condensed" style="width: 100%">
					<thead class="text-center">
						<tr>
							<th>Id Categoria</th>
							<th>Nombre Categoria</th>
							<th>Acciones</th>
						</tr>
					</thead>
					<tbody>
							<?php
					foreach($data as $dat)
					{ 
					?>
					<tr>
					<td><?php echo $dat ['id_categoria']?></td>
					<td><?php echo $dat ['nombre_categoria']?></td>
					<td></td>
					</tr>
					<?php
					}
						?>
					</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	
	<!-- Modal Crud-->
	<div class="modal fade" id="modalCrud" tabindex="-1" role="dialog" aria-labelledby="examploModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title" id="examploModalLabel"></h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<form id="formCategoria">
				<div class="modal-body">
				<div class="form-group">
					<label for="nombre_categoria" class="col-form-label">Nombre Categoria:</label>
					<input type="text" class="form-control" id="nombre_categoria"
					</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-light" data-dismiss="modal">Cancelar</button>
							<button type="submit" id="btnGuardar" class="btn btn-dark">Guardar</button>
							</div>	
			</form>
		</div>
		</div>
	</div>
		
		<!--Jquery, Popper, Bootstrap -->
		<script src="jquery/jquery-3.3.1.min.js"></script>
		<script src="popper/popper.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
		
		<!-- Datatable -->
		<script type="text/javascript" src="datatables/datatables.min.js"></script>
				<script type="text/javascript" src="main.js"></script>
	
</body>
</html>