$(document).ready(function(){
	tablaCategoria = $("#tablaCategoria").DataTable({
		"columnDefs":[{
			"targets":-1,
			"data":null,
			"defaultContent":"<div class='text-center'><div class='btn-group'><button class='btn btn-primary btnEditar'>Editar</button><button class='btn btn-danger btnBorrar'>Borrar</button></div></div>"
		}],
		"language": {
                "lengthMenu": "Mostrar _MENU_ registros",
                "zeroRecords": "No se encontraron resultados",
                "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sSearch": "Buscar:",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast":"Último",
                    "sNext":"Siguiente",
                    "sPrevious": "Anterior"
			     },
			     "sProcessing":"Procesando...",
            }
	});
	
	$("#btnNuevo").click(function(){
		
		$("#formCategoria").trigger("reset");
		$(".modal-header").css("background-color","#28A745");
		$(".modal-header").css("color","white");
		$(".modal-title").text("Nueva Categoria");
		$("#modalCrud").modal("show");
		id_categoria=null;
		opcion = 1; //alta o nuevo
	});
	
		var fila; //captura la fila para modificar y elimitar
	//codigo boton editar
$(document).on("click", ".btnEditar", function(){
    fila = $(this).closest("tr");
    id_categoria = parseInt(fila.find('td:eq(0)').text());
    nombre_categoria = fila.find('td:eq(1)').text();
    
    $("#nombre_categoria").val(nombre_categoria);
    opcion = 2; //editar
    
    $(".modal-header").css("background-color", "#007bff");
    $(".modal-header").css("color", "white");
    $(".modal-title").text("Editar categoria");            
    $("#modalCrud").modal("show");  
    
});
	
	$(document).on("click", ".btnBorrar", function(){
		fila = $(this);
		id_categoria = parseInt($(this).closest("tr").find('td:eq(0)').text());
		
		opcion = 3; //eliminar
		
		var respuesta = confirm("¿Seguro que desea eliminar esta categoria "+id_categoria+"?");
		if(respuesta){
			$.ajax({
				url:"crud.php",
				type: "POST",
				dataType: "json",
				data:{ opcion:opcion, id_categoria:id_categoria},
				success: function(){
					tablaCategoria.row(fila.parents('tr')).remove().draw();
				}
			});
		}
	});
	
	$("#formCategoria").submit(function(e)
{
	e.preventDefault();
	nombre_categoria = $.trim($("#nombre_categoria").val());
		
		$.ajax({
			url: "crud.php",
			type: "POST",
			dataType: "json",
			data:{nombre_categoria:nombre_categoria, id_categoria:id_categoria, opcion:opcion},
			success: function(data)
			{
				console.log(data);
				id_categoria = data [0].id_categoria;
				nombre_categoria = data [0].nombre_categoria;
				if(opcion==1)
				{
					tablaCategoria.row.add([id_categoria ,nombre_categoria]).draw();
				}
				else{tablaCategoria.row(fila).data([id_categoria ,nombre_categoria]).draw();}
				
			}
						
		});
		
		$("#modalCrud").modal("hide");
		
});
	
});