CREATE DATABASE categorias;
USE categorias:
CREATE TABLE libro(
id_categoria INT NOT NULL AUTO_INCREMENT,
nombre_categoria VARCHAR (50),
PRIMARY KEY (id_categoria)
)