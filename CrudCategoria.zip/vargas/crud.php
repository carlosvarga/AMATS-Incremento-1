<?php

include_once "conexion.php";
$objeto = new conexion();
$conexion = $objeto->conectar();

//recepcion de datos enviados mediante metodo post

$nombre_categoria = (isset($_POST['nombre_categoria'])) ? $_POST['nombre_categoria'] : '';
$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';
$id_categoria = (isset($_POST['id_categoria'])) ? $_POST['id_categoria'] : '';


switch($opcion)
{
	case 1:
$consulta = "INSERT INTO categoria (nombre_categoria) VALUE ('$nombre_categoria')";
$resultado = $conexion->prepare($consulta);
$resultado->execute();

$consulta = "SELECT id_categoria, nombre_categoria FROM categoria ORDER BY id_categoria DESC LIMIT 1";
$resultado = $conexion->prepare($consulta);
$resultado->execute();

$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
		
		break;
	case 2:
		 $consulta = "UPDATE categoria SET nombre_categoria='$nombre_categoria' WHERE id_categoria='$id_categoria' ";	
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();        
        
        $consulta = "SELECT id_categoria, nombre_categoria FROM categoria WHERE id_categoria='$id_categoria' ";       
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
		break;
	case 3:
		$consulta = "DELETE FROM categoria WHERE id_categoria='$id_categoria' ";
		$resultado = $conexion->prepare($consulta);
        $resultado->execute();
		$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
		break;
}

print json_encode($data, JSON_UNESCAPED_UNICODE);  //Enviae Array final

$conexion = NULL;
?>